import { T } from './tokens';

export function PrimaryButton({ label, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        background: T.primary,
        color: T.white,
        height: 52,
        borderRadius: 14,
        fontSize: 15,
        fontWeight: 700,
        padding: '0 24px',
        border: 'none',
      }}
    >
      {label}
    </button>
  );
}

export function Card({ children }) {
  return (
    <div style={{
      background: T.white,
      borderRadius: 14,
      padding: 16,
      boxShadow: '0 2px 8px rgba(15,15,26,0.06)',
    }}>
      {children}
    </div>
  );
}
