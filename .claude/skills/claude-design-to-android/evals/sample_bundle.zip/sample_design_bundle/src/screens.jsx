import { T } from './tokens';
import { PrimaryButton, Card } from './components';

export function S01Welcome({ onContinue }) {
  return (
    <div style={{ background: T.bg, padding: 24, height: 844 }}>
      <h1 style={{ fontSize: 28, fontWeight: 800, color: T.ink, letterSpacing: -0.5 }}>
        Welcome to SampleApp
      </h1>
      <p style={{ fontSize: 15, color: T.muted, marginTop: 8 }}>
        Get started in just a moment.
      </p>
      <div style={{ marginTop: 32 }}>
        <PrimaryButton label="Continue" onClick={onContinue} />
      </div>
    </div>
  );
}

export function S02Home({ onAddItem }) {
  return (
    <div style={{ background: T.bg, padding: 16 }}>
      <Card>
        <div style={{ fontSize: 17, fontWeight: 600, color: T.ink }}>Today</div>
        <div style={{ fontSize: 13, color: T.muted, marginTop: 4 }}>
          Nothing yet — tap + to add something.
        </div>
      </Card>
    </div>
  );
}

export function S03Detail({ id, onBack }) {
  return (
    <div style={{ background: T.white, padding: 16 }}>
      <button onClick={onBack} style={{ color: T.ink }}>← Back</button>
      <h2 style={{ fontSize: 22, fontWeight: 700, color: T.ink, marginTop: 16 }}>
        Item {id}
      </h2>
    </div>
  );
}
