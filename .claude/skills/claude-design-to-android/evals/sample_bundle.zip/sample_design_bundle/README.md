# Sample App

A tiny three-screen design for testing the claude-design-to-android skill.

Screens:
1. Welcome — splash with primary CTA
2. Home — empty state card
3. Detail — back button + item title
