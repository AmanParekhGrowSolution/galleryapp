// Design tokens for the sample app
export const T = {
  primary: 'rgb(37,100,207)',
  ink: '#131111',
  muted: 'rgb(110,110,128)',
  hair: 'rgba(15,15,26,0.08)',
  white: '#FFFFFF',
  danger: '#E53935',
  bg: '#FAFAFC',
};

export const RADII = {
  card: 14,
  pill: 999,
  sheet: 24,
};
