import { useState } from 'react';
import { S01Welcome, S02Home, S03Detail } from './screens';

export function App() {
  const [screen, setScreen] = useState('welcome');
  const [detailId, setDetailId] = useState(null);

  if (screen === 'welcome') return <S01Welcome onContinue={() => setScreen('home')} />;
  if (screen === 'home') return <S02Home onAddItem={() => setScreen('detail')} />;
  if (screen === 'detail') return <S03Detail id={detailId} onBack={() => setScreen('home')} />;
}
