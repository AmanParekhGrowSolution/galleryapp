import logo from '/assets/Logo.png';
export function Splash() {
  return (
    <div style={{ background: 'url(/public/img/hero-bg.jpg)' }}>
      <img src="/assets/check.svg" alt="check" />
      <img src={logo} alt="Logo" />
      <img src="avatar@2x.png" alt="user" />
      <img src="/assets/01-onboarding.png" alt="step 1" />
    </div>
  );
}
